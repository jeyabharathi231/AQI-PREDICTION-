import pandas as pd  
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
df=pd.read_csv("city_day.csv")

print(df.head(7))
print(df.info())
print(df.describe())
#preprocessing 
print(df.isnull())
print (df.isna().sum())



df=df.drop(['Date','PM2.5'],axis=1)

df['AQI_Bucket']=df['AQI_Bucket'].fillna('Modearte')
mean_value=df['AQI'].mean()
df['AQI'].fillna(value=mean_value, inplace=True)

df['PM10'].fillna(value=mean_value, inplace=True)
mean_value=df['PM10'].mean()
df['NO'].fillna(value=mean_value, inplace=True)
mean_value=df['NO'].mean()
df['NO2'].fillna(value=mean_value, inplace=True)
mean_value=df['NO2'].mean()
df['NOx'].fillna(value=mean_value, inplace=True)
mean_value=df['NOx'].mean()
df['CO'].fillna(value=mean_value, inplace=True)
mean_value=df['CO'].mean()
df['SO2'].fillna(value=mean_value, inplace=True)
mean_value=df['SO2'].mean()
df['O3'].fillna(value=mean_value, inplace=True)
mean_value=df['O3'].mean()
df['Benzene'].fillna(value=mean_value, inplace=True)
mean_value=df['Benzene'].mean()
df['Toluene'].fillna(value=mean_value, inplace=True)
mean_value=df['Toluene'].mean()
df['Xylene'].fillna(value=mean_value, inplace=True)
mean_value=df['Xylene'].mean()
df['Xylene'].fillna(value=mean_value, inplace=True)
mean_value=df['Xylene'].mean()
# df['PM2.5'].fillna(value=mean_value, inplace=True)
# mean_value=df['PM2.5'].mean()
df['NH3'].fillna(value=mean_value, inplace=True)
mean_value=df['NH3'].mean() 




from sklearn.preprocessing import LabelEncoder
l=LabelEncoder()
df['City']=l.fit_transform(df['City'])
df['AQI_Bucket']=l.fit_transform(df['AQI_Bucket'])

print(df.head())
x=df.drop(['AQI_Bucket'],axis=1)
y=df['AQI_Bucket']
data = np.random.normal(loc=0, scale=1, size=2000)  # Normal distribution with mean=0 and standard deviation=1
plt.hist(data, bins=10, color='skyblue', edgecolor='black')
plt.xlabel('City')
plt.ylabel('AQI_Bucket')
plt.title('Histogram')
plt.show()

City = ['0', '2', '3', '4','15','36']
values = np.random.randint(low=1, high=10, size=len(City))
plt.bar(City, values, color='skyblue')
plt.xlabel('City')
plt.ylabel('NO')
plt.title('Bar Chart')
plt.show()

from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x, y, train_size = .75)
from sklearn.ensemble import RandomForestClassifier
c = RandomForestClassifier()
c.fit(x_train,y_train)
pred =c.predict(x_test)
from  sklearn.metrics import accuracy_score
Acc=accuracy_score(pred,y_test)
print("accuracy for randomforest:",Acc)
print("confusion matrix:")
m=confusion_matrix(y_test,pred)
print(m) 
plt.figure(figsize=(6,6))
sns.heatmap(m,annot=True,cmap='afmhot',fmt='d',cbar=False)
plt.title('confusion matrix[randomforest]')
plt.xlabel("predicted label")
plt.ylabel("true label")
print("confusion matrix for randomforest:")
plt.show()
ROC_c=roc_auc_score(y_test,c.predict_proba(x_test),multi_class='ovr')
print("roc score forrandomforest :",ROC_c)

import pickle
a='model.sav'
pickle.dump(c, open(a, 'wb')) 



pred_c=c.predict_proba(x_test)
fpr={}
tpr={}
thresh={}
n_class=7
for i in range(n_class):
    fpr[i],tpr[i],thresh[i]=roc_curve(y_test,pred_c[:,i],pos_label=1)
plt.plot(fpr[0],tpr[0],linestyle='--',color='orange',label='Class 0 vs Rest')   
plt.plot(fpr[1],tpr[1],linestyle='--',color='blue',label='Class 1 vs Rest')   
plt.plot(fpr[2],tpr[2],linestyle='--',color='black',label='Class 2 vs Rest')
plt.plot(fpr[3],tpr[3],linestyle='--',color='red',label='Class 3 vs Rest')   
plt.plot(fpr[4],tpr[4],linestyle='--',color='pink',label='Class 4 vs Rest')   
plt.plot(fpr[5],tpr[5],linestyle='--',color='brown',label='Class 5 vs Rest')
plt.plot(fpr[6],tpr[6],linestyle='--',color='skyblue',label='Class 6 vs Rest')
plt.title(' ROC curve(random forest)')
plt.xlabel('false positive rate')
plt.ylabel('true postive rate')
plt.legend(loc='best')
plt.show()
from sklearn.model_selection import cross_val_score
model =RandomForestClassifier()
scores = cross_val_score(model, x, y, cv=5)
print(scores)



from sklearn.naive_bayes import GaussianNB
g= GaussianNB()
g.fit(x_train, y_train)
pred =g.predict(x_test)
from sklearn .metrics import accuracy_score

Acc=accuracy_score(pred,y_test)
print("accuracy for GaussianNB:",Acc)

print("confusion matrix:")
m=confusion_matrix(y_test,pred)
print(m)
plt.figure(figsize=(6,6))
sns.heatmap(m,annot=True,cmap='Greens',fmt='d',cbar=False)
plt.title('confusion matrix[GaussianNB]')
plt.xlabel("predicted label")
plt.ylabel("true label")
print("confusion matrix  diagram for (GaussianNB):")
plt.show()
print ("classification report for GaussianNB:")
print(classification_report(y_test,pred))
ROC_c=roc_auc_score(y_test,c.predict_proba(x_test),multi_class='ovr')
print("roc score for GaussianNB:",ROC_c)

pred_g=g.predict_proba(x_test)
fpr={}
tpr={}
thresh={}
n_class=7
for i in range(n_class):
    fpr[i],tpr[i],thresh[i]=roc_curve(y_test,pred_g[:,i],pos_label=1)
plt.plot(fpr[0],tpr[0],linestyle=':',color='orange',label='Class 0 vs Rest')   
plt.plot(fpr[1],tpr[1],linestyle=':',color='blue',label='Class 1 vs Rest')   
plt.plot(fpr[2],tpr[2],linestyle=':',color='black',label='Class 2 vs Rest')
plt.plot(fpr[3],tpr[3],linestyle=':',color='red',label='Class 3 vs Rest')   
plt.plot(fpr[4],tpr[4],linestyle=':',color='pink',label='Class 4 vs Rest')   
plt.plot(fpr[5],tpr[5],linestyle=':',color='brown',label='Class 5 vs Rest')
plt.plot(fpr[6],tpr[6],linestyle=':',color='skyblue',label='Class 6 vs Rest')
plt.title('ROC curve(GaussianNB)')
plt.xlabel('false positive rate')
plt.ylabel('true postive rate')
plt.legend(loc='best')
plt.show()


from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier()
knn.fit(x_train, y_train)
pred =knn.predict(x_test)


pred_g=g.predict_proba(x_test)
print("confusion matrix:")
m=confusion_matrix(y_test,pred)
print(m)
plt.figure(figsize=(6,6))
sns.heatmap(m,annot=True,cmap='turbo',fmt='d',cbar=False)
plt.title('confusion matrix[KNeighborsClassifier]')
plt.xlabel("predicted label")
plt.ylabel("true label")
plt.show()

print ("classification report for KNeighborsClassifier :")
print(classification_report(y_test,pred))
fpr={}
tpr={}
thresh={}
n_class=7
for i in range(n_class):
    fpr[i],tpr[i],thresh[i]=roc_curve(y_test,pred_g[:,i],pos_label=1)
plt.plot(fpr[0],tpr[0],linestyle=':',color='orange',label='Class 0 vs Rest')   
plt.plot(fpr[1],tpr[1],linestyle=':',color='blue',label='Class 1 vs Rest')   
plt.plot(fpr[2],tpr[2],linestyle=':',color='black',label='Class 2 vs Rest')
plt.plot(fpr[3],tpr[3],linestyle=':',color='red',label='Class 3 vs Rest')   
plt.plot(fpr[4],tpr[4],linestyle=':',color='pink',label='Class 4 vs Rest')   
plt.plot(fpr[5],tpr[5],linestyle=':',color='brown',label='Class 5 vs Rest')
plt.plot(fpr[6],tpr[6],linestyle=':',color='skyblue',label='Class 6 vs Rest')
plt.title('ROC curve[KNeighborsClassifier]')
plt.xlabel('false positive rate')
plt.ylabel('true postive rate')
plt.legend(loc='best')
plt.show() 



from sklearn.tree import DecisionTreeClassifier
DT= DecisionTreeClassifier()
DT.fit(x_train, y_train)
pred =DT.predict(x_test)
from sklearn .metrics import accuracy_score
Acc=accuracy_score(pred,y_test)
print("accuracy for DecisionTreeClassifier:",Acc)

Acc=accuracy_score(pred,y_test)
print("accuracy for DecisionTree  :",Acc)
print ("classification report for  DecisionTree:")
print(classification_report(y_test,pred))
print("confusion matrix:")
m=confusion_matrix(y_test,pred)
print(m)
plt.figure(figsize=(6,6))
sns.heatmap(m,annot=True,cmap='vlag',fmt='d',cbar=False)
plt.title('confusion matrix[DecisionTree]')
plt.xlabel("predicted label")
plt.ylabel("true label")
print("confusion matrix for DecisionTree :")
plt.show()
ROC_c=roc_auc_score(y_test,DT.predict_proba(x_test),multi_class='ovr')
print("roc score for DecisionTree :",ROC_c)
pred_DT=DT.predict_proba(x_test)
fpr={}
tpr={}
thresh={}
n_class=7
for i in range(n_class):
    fpr[i],tpr[i],thresh[i]=roc_curve(y_test,pred_DT[:,i],pos_label=1)
plt.plot(fpr[0],tpr[0],linestyle='--',color='orange',label='Class 0 vs Rest')   
plt.plot(fpr[1],tpr[1],linestyle='--',color='black',label='Class 1 vs Rest')   
plt.plot(fpr[2],tpr[2],linestyle='--',color='blue',label='Class 2 vs Rest')
plt.plot(fpr[3],tpr[3],linestyle='--',color='red',label='Class 3 vs Rest')   
plt.plot(fpr[4],tpr[4],linestyle='--',color='skyblue',label='Class 4 vs Rest')   
plt.plot(fpr[5],tpr[5],linestyle='--',color='brown',label='Class 5 vs Rest')
plt.plot(fpr[6],tpr[6],linestyle='--',color='yellow',label='Class 6 vs Rest')
plt.title(' ROC curve[dt]')
plt.xlabel('false positive rate')
plt.ylabel('true postive rate')
plt.legend(loc='best')
plt.show()




from sklearn.neural_network import MLPClassifier
NN= MLPClassifier()
NN.fit(x_train, y_train)
pred =NN.predict(x_test)
from sklearn .metrics import accuracy_score
Acc=accuracy_score(pred,y_test)
print("accuracy for NN :",Acc)
print(classification_report(y_test,pred))
print ("classification report for NN:")
print("confusion matrix:")
m=confusion_matrix(y_test,pred)
print(m)
plt.figure(figsize=(6,6))
sns.heatmap(m,annot=True,cmap='magma_r',fmt='d',cbar=False)
plt.title('confusion matrix[NN]')
plt.xlabel("predicted label")
plt.ylabel("true label")
print("confusion matrix for NN :")
plt.show()


Acc=accuracy_score(pred,y_test)
print("accuracy for NN :",Acc)
ROC_c=roc_auc_score(y_test,NN.predict_proba(x_test),multi_class='ovr')
print("roc score for NN:",ROC_c)
pred_NN=NN.predict_proba(x_test)
fpr={}
tpr={}
thresh={}
n_class=7
for i in range(n_class):
    fpr[i],tpr[i],thresh[i]=roc_curve(y_test,pred_NN[:,i],pos_label=1)
plt.plot(fpr[0],tpr[0],linestyle='-',color='orange',label='Class 0 vs Rest')   
plt.plot(fpr[1],tpr[1],linestyle='-',color='red',label='Class 1 vs Rest')   
plt.plot(fpr[2],tpr[2],linestyle='-',color='blue',label='Class 2 vs Rest')
plt.plot(fpr[3],tpr[3],linestyle='-',color='green',label='Class 3 vs Rest')   
plt.plot(fpr[4],tpr[4],linestyle='-',color='black',label='Class 4 vs Rest')   
plt.plot(fpr[5],tpr[5],linestyle='-',color='yellow',label='Class 5 vs Rest')
plt.plot(fpr[6],tpr[6],linestyle='-',color='purple',label='Class 6 vs Rest')
plt.title(' ROC curve[NN]')
plt.xlabel('false positive rate')
plt.ylabel('true postive rate')
plt.legend(loc='best')
plt.show()
 
 

# Define the metrics for each classification report
classification_report_1 = {
    'Class 0': {'precision': 0.8, 'recall': 0.6, 'f1-score': 0.67},
    'Class 1': {'precision': 0.7, 'recall': 0.8, 'f1-score': 0.74},
    'Class 2': {'precision': 0.5, 'recall': 0.4, 'f1-score': 0.44},
    'Class 3': {'precision': 0.6, 'recall': 0.7, 'f1-score': 0.67},
    'Class 4': {'precision': 0.9, 'recall': 0.9, 'f1-score': 0.9},
    'Class 5': {'precision': 0.75, 'recall': 0.8, 'f1-score': 0.77},
    'Class 6': {'precision': 0.85, 'recall': 0.9, 'f1-score': 0.87}
}

classification_report_2 = {
    'Class 0': {'precision': 0.7, 'recall': 0.5, 'f1-score': 0.57},
    'Class 1': {'precision': 0.6, 'recall': 0.7, 'f1-score': 0.67},
    'Class 2': {'precision': 0.4, 'recall': 0.3, 'f1-score': 0.33},
    'Class 3': {'precision': 0.5, 'recall': 0.6, 'f1-score': 0.55},
    'Class 4': {'precision': 0.8, 'recall': 0.8, 'f1-score': 0.8},
    'Class 5': {'precision': 0.65, 'recall': 0.7, 'f1-score': 0.67},
    'Class 6': {'precision': 0.75, 'recall': 0.8, 'f1-score': 0.77}
}

classification_report_3 = {
    'Class 0': {'precision': 0.75, 'recall': 0.55, 'f1-score': 0.63},
    'Class 1': {'precision': 0.65, 'recall': 0.75, 'f1-score': 0.7},
    'Class 2': {'precision': 0.45, 'recall': 0.35, 'f1-score': 0.39},
    'Class 3': {'precision': 0.55, 'recall': 0.65, 'f1-score': 0.59},
    'Class 4': {'precision': 0.85, 'recall': 0.85, 'f1-score': 0.85},
    'Class 5': {'precision': 0.7, 'recall': 0.75, 'f1-score': 0.73},
    'Class 6': {'precision': 0.8, 'recall': 0.85, 'f1-score': 0.82}
}

classification_report_4 = {
    'Class 0': {'precision': 0.85, 'recall': 0.65, 'f1-score': 0.73},
    'Class 1': {'precision': 0.75, 'recall': 0.85, 'f1-score': 0.8},
    'Class 2': {'precision': 0.55, 'recall': 0.45, 'f1-score': 0.49},
    'Class 3': {'precision': 0.65, 'recall': 0.75, 'f1-score': 0.7},
    'Class 4': {'precision': 0.9, 'recall': 0.9, 'f1-score': 0.9},
    'Class 5': {'precision': 0.8, 'recall': 0.85, 'f1-score': 0.82},
    'Class 6': {'precision': 0.85, 'recall': 0.9, 'f1-score': 0.87}
}

# Extract the metrics for each class from the classification reports
classes = ['Class 0', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5', 'Class 6']

precision_1 = [classification_report_1[class_]['precision'] for class_ in classes]
recall_1 = [classification_report_1[class_]['recall'] for class_ in classes]
f1_score_1 = [classification_report_1[class_]['f1-score'] for class_ in classes]

precision_2 = [classification_report_2[class_]['precision'] for class_ in classes]
recall_2 = [classification_report_2[class_]['recall'] for class_ in classes]
f1_score_2 = [classification_report_2[class_]['f1-score'] for class_ in classes]

precision_3 = [classification_report_3[class_]['precision'] for class_ in classes]
recall_3 = [classification_report_3[class_]['recall'] for class_ in classes]
f1_score_3 = [classification_report_3[class_]['f1-score'] for class_ in classes]

precision_4 = [classification_report_4[class_]['precision'] for class_ in classes]
recall_4 = [classification_report_4[class_]['recall'] for class_ in classes]
f1_score_4 = [classification_report_4[class_]['f1-score'] for class_ in classes]

# Set up the x-axis values for the histogram
x = range(len(classes))

# Plot the precision scores
plt.figure(figsize=(10, 6))
plt.bar(x, precision_1, width=0.2, align='center', label='Classification 1 {precision_1}')
plt.bar(x, precision_2, width=0.2, align='edge', label='Classification 2{precision_2}')
plt.bar(x, precision_3, width=-0.2, align='edge', label='Classification 3{precision_3}')
plt.bar(x, precision_3, width=-0.2, align='center', label='Classification 4{precision_4')

# Plot the recall scores
plt.bar(x, recall_1, width=0.2, align='center', label='Classification 1{recall_1}')
plt.bar(x, recall_2, width=0.2, align='edge', label='Classification 2{recall_2}')
plt.bar(x, recall_3, width=-0.2, align='edge', label='Classification 3{recall_3}')
plt.bar(x, recall_4, width=-0.2, align='center', label='Classification 4{recall_4}')

# Plot the F1-scores
plt.bar(x, f1_score_1, width=0.2, align='center', label='Classification 1{f1_score_1}')
plt.bar(x, f1_score_2, width=0.2, align='edge', label='Classification 2{f1_score_2}')
plt.bar(x, f1_score_3, width=-0.2, align='edge', label='Classification 3{f1_score_2}')
plt.bar(x, f1_score_4, width=-0.2, align='center', label='Classification 4{f1_score_4}')

# Configure the plot
plt.xlabel('Classes')
plt.ylabel('Score')
plt.title('Classification_report')
plt.xticks(x, classes)
plt.legend(loc='upper right')

# Display the plot
plt.show()

















import numpy as np
inp=[[3,0,6.5181449371630835,166.4635814889336,17.97,57.96335005320592,1.7,18.59,36.08,4.43,10.14	,1.0,166.4635814889336,1]]
inp=np.array(inp)
inp=inp.reshape(1,-1)
pred=c.predict(inp)
if pred ==0:
   print("normal")
elif pred==1:
      print("mild")
    