a=(1,2,3,3,4,6,8,9)
print("length of the tuple",len(a))
x=a.index(3)
print(x)
