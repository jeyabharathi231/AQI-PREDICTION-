# Importing Libraries:
import pandas as pd
import numpy as np
import pickle

# for displaying all feature from dataset:
pd.pandas.set_option('display.max_columns', None)

# Reading Dataset:
df= pd.read_csv("city_day.csv")

print(df.isnull())
print (df.isna().sum())



df=df.drop(['Date','PM2.5'],axis=1)

df['AQI_Bucket']=df['AQI_Bucket'].fillna('Modearte')
mean_value=df['AQI'].mean()
df['AQI'].fillna(value=mean_value, inplace=True)

df['PM10'].fillna(value=mean_value, inplace=True)
mean_value=df['PM10'].mean()
df['NO'].fillna(value=mean_value, inplace=True)
mean_value=df['NO'].mean()
df['NO2'].fillna(value=mean_value, inplace=True)
mean_value=df['NO2'].mean()
df['NOx'].fillna(value=mean_value, inplace=True)
mean_value=df['NOx'].mean()
df['CO'].fillna(value=mean_value, inplace=True)
mean_value=df['CO'].mean()
df['SO2'].fillna(value=mean_value, inplace=True)
mean_value=df['SO2'].mean()
df['O3'].fillna(value=mean_value, inplace=True)
mean_value=df['O3'].mean()
df['Benzene'].fillna(value=mean_value, inplace=True)
mean_value=df['Benzene'].mean()
df['Toluene'].fillna(value=mean_value, inplace=True)
mean_value=df['Toluene'].mean()
df['Xylene'].fillna(value=mean_value, inplace=True)
mean_value=df['Xylene'].mean()
df['Xylene'].fillna(value=mean_value, inplace=True)
mean_value=df['Xylene'].mean()
# df['PM2.5'].fillna(value=mean_value, inplace=True)
# mean_value=df['PM2.5'].mean()
df['NH3'].fillna(value=mean_value, inplace=True)
mean_value=df['NH3'].mean() 




from sklearn.preprocessing import LabelEncoder
l=LabelEncoder()
df['City']=l.fit_transform(df['City'])
df['AQI_Bucket']=l.fit_transform(df['AQI_Bucket'])


# Droping 'Direct_Bilirubin' feature:
x=df.drop(['AQI_Bucket'],axis=1)
y=df['AQI_Bucket']
X = df.iloc[:, :-1]
y = df.iloc[:, -1]
# SMOTE Technique:


# Train Test Split:
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size = .75,random_state=33)

# RandomForestClassifier:
from sklearn.ensemble import RandomForestClassifier
RandomForest = RandomForestClassifier()
RandomForest = RandomForest.fit(x_train,y_train)

# Creating a pickle file for the classifier
filename = 'Liver2.pkl'
pickle.dump(RandomForest, open(filename, 'wb'))