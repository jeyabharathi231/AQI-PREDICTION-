import pandas as pd  
import matplotlib.pyplot as plt
df=pd.read_csv("fraud.csv")
print(df.head(7))
print(df.info())
print(df.describe())
#preprocessing 
print(df.isnull())
print (df.isna().sum())
df=df.fillna(0)
from sklearn.preprocessing import LabelEncoder
l=LabelEncoder()
df['Time']=l.fit_transform(df['Time'])
print(df.head())
x=df.drop(['Amount'],axis=1)
y=df['Amount']
plt.bar(df['Time'],df['Amount'],color="blue",width=0.8)
plt.show()
plt.bar(df['NO'],df['Amount'],color="blue",width=0.8)
plt.show()
from sklearn.model_selection import train_test_split
features = ['V1','V2','V3','V4','V5']
X = df.loc[:, features]
y = df.loc[:, ['Amount']]
X_train, X_test, y_train, y_test = train_test_split(x, y, random_state=0, train_size = .75)
from sklearn import svm
s= svm.SVC(kernel='linear')
s.fit(X_train, y_train)
y_pred = s.predict(X_test)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))







