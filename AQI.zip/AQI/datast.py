#to print the list
list=(1,2,3,3,4,6,8,9)
print("length of the tuple",len(list))

#to print the index value of the list element
x=list.index(3)
print(x)

#to check the list allow duplicate or not
list1 = ["apple", "banana", "cherry", "apple", "cherry"]
print(list1)

#list with int,string,boolean datatype
list2 = ["abc", 34, True, 40, "male"]
print(list2)

#to print the element with index value
list3= ["apple", "banana", "cherry","kiwi", "melon", "mango"]
print(list3[2:5])
print(list3[:4])#not including the index 4
print(list3[2:])
#add 
list3.append("orange")
print(list3)
list1.insert(1, "orange")
print(list1)
#delete
list3.remove("banana")
print(list3)
list3.pop(4)
print(list3)







tuple=(1,2,3,3,4,6,8,9)
print("length of the tuple",len(tuple))

#to print the index value of the list element
x=tuple.index(3)
print(x)

#to check the list allow duplicate or not
t1 = ("apple", "banana", "cherry", "apple", "cherry")
print(t1)

#list with int,string,boolean datatype
t2 = ("abc", 34, True, 40, "male")
print(t2)

#to print the element with index value
t3= ("apple", "banana", "cherry","kiwi", "melon", "mango")
print(t3[2:5])
print(t3[:4])#not including the index 4
print(t3[2:])

#add 
tuple1 = ("a", "b" , "c")
tuple2 = (1, 2, 3)
tuple3 = tuple1 + tuple2
print(tuple3)






#set
set = {"apple", "banana", "cherry", True, 1, 2}
print(set)
print(len(set))

#addset
set1 = {"apple", "banana", "cherry"}
set1.add("orange")
print(set1)

#to remove
set2 = {"apple", "banana", "cherry"}
set2.remove("banana")
print(set2)

#accese the set
print("banana" in set2)







#print the set
dict={"1":"apple","2":"orange","3":"melon"}
print(dict)

#length
print(len(dict))
#update
dict.update({"4": 333})
print(dict)
#to access the dict
x = dict.keys()
#to update
dict.update({"1": "red"})
print(dict)
#remove
del dict["2"]
print(dict)




#print str
a = "Hello"
print(a)
#string accesing
a = "string"
print(a[1])
#slicing
b = "Hello, World!"
print(b[2:5])
#to change in uppercase
a = "Hello, World!"
print(a.upper())
#to change in lower
a = "Hello, World!"
print(a.lower())
#to remove the white space
a = "  Hello,World! "
print(a.strip())
#to split the string 
a = "Hello, World!"
print(a.split(","))
# concatenation
a = "Hello"
b = "World"
c = a + b
print(c)

