from tkinter  import *
import pandas as pd
from sklearn.model_selection import train_test_split
import pickle
from sklearn.ensemble import RandomForestClassifier
def prediction_model():
    x = [[int(entry_1.get()), int(entry_2.get()), int(entry_3.get()), int(entry_4.get()), int(entry_5.get()), int(entry_6.get()), int(entry_7.get()), int(entry_8.get()), int(entry_9.get()), float(entry_10.get()), int(entry_11.get()), int(entry_12.get()), int(entry_13.get())]]
    randomforest = pickle.load(open('models.sav', 'rb'))
    aqi= randomforest.predict(x) 
    if aqi <= 50:
       myText.set("Air quality is Good")
       myText.config(bg="green")
    elif aqi <= 100:
       myText.set("Air quality is Satisfactory")
    elif aqi <= 200:
      myText.set("Air quality is Moderate")
    elif aqi <= 300:
     myText.set("Air quality is Poor")
    elif aqi <= 400:
     myText.set("Air quality is Very Poor")
    else:
       myText.set("Air quality is Severe")   

df=pd.read_csv("city_day.csv")
df['AQI_Bucket']=df['AQI_Bucket'].fillna('Modearte')
mean_value=df['AQI'].mean()
df['AQI'].fillna(value=mean_value, inplace=True)

df['PM10'].fillna(value=mean_value, inplace=True)
mean_value=df['PM10'].mean()
df['NO'].fillna(value=mean_value, inplace=True)
mean_value=df['NO'].mean()
df['NO2'].fillna(value=mean_value, inplace=True)
mean_value=df['NO2'].mean()
df['NOx'].fillna(value=mean_value, inplace=True)
mean_value=df['NOx'].mean()
df['CO'].fillna(value=mean_value, inplace=True)
mean_value=df['CO'].mean()
df['SO2'].fillna(value=mean_value, inplace=True)
mean_value=df['SO2'].mean()
df['O3'].fillna(value=mean_value, inplace=True)
mean_value=df['O3'].mean()
df['Benzene'].fillna(value=mean_value, inplace=True)
mean_value=df['Benzene'].mean()
df['Toluene'].fillna(value=mean_value, inplace=True)
mean_value=df['Toluene'].mean()

df['Xylene'].fillna(value=mean_value, inplace=True)
mean_value=df['Xylene'].mean()
df['NH3'].fillna(value=mean_value, inplace=True)
mean_value=df['NH3'].mean() 
from sklearn.preprocessing import LabelEncoder
l=LabelEncoder()
df['City']=l.fit_transform(df['City'])
df['AQI_Bucket']=l.fit_transform(df['AQI_Bucket'])
df=df.drop(['Date'],axis=1)
df=df.drop(['PM2.5'],axis=1)
predictors =df.drop(['AQI_Bucket'],axis=1)
target=df['AQI_Bucket']
x_train, x_val, y_train, y_val = train_test_split(predictors, target, test_size = 0.22, random_state = 0)
randomforest = RandomForestClassifier()
randomforest.fit(x_train, y_train)
y_pred = randomforest.predict(x_val)
filename = 'model.sav'
pickle.dump(randomforest, open('models.sav', 'wb'))
root = Tk()
label = Label(root, text="Hello World")



win=Tk()
win.geometry("550x780")
win.title("AQI")
label.grid(row=0, column=0)
regTitle=Label(win,text="Air Quality Index",width=50,font=("bold",30))
City=Label(win,text="city name(0-25):",width=50,font=("bold",13)) 
PM10=Label(win,text="particulate matter 10:",width=50,font=("bold",13))
NO=Label(win,text="NO",width=50,font=("bold",13))
NO2=Label(win,text="NO2:",width=50,font=("bold",13))
NOx=Label(win,text="NOx:",width=50,font=("bold",13))
NH3=Label(win,text="NH3:",width=50,font=("bold",13))
CO=Label(win,text="CO:",width=50,font=("bold",13))
SO2=Label(win,text="SO2:",width=50,font=("bold",13))
O3=Label(win,text="O3:",width=50,font=("bold",13))
Benzene=Label(win,text="BENZENE:",width=50,font=("bold",13))
Toluene=Label(win,text="TOLUENE:",width=50,font=("bold",13))
Xylene=Label(win,text="XYLENE:",width=50,font=("bold",13))
AQI=Label(win,text="AQI:",width=50,font=("bold",13)) 
entry_1=Entry(win,width=10)
entry_2=Entry(win,width=10)
entry_3=Entry(win,width=10)
entry_4=Entry(win,width=10)
entry_5=Entry(win,width=10)
entry_6=Entry(win,width=10)
entry_7=Entry(win,width=10)
entry_8=Entry(win,width=10)
entry_9=Entry(win,width=10)
entry_10=Entry(win,width=10)
entry_11=Entry(win,width=10)
entry_12=Entry(win,width=10)
entry_13=Entry(win,width=10)









regTitle.grid(row=0,pady=10)
City.grid(row=2, pady=10)
PM10.grid(row=4, pady=10)
NO.grid(row=6, pady=10)
NO2.grid(row=8, pady=10)
NOx.grid(row=10, pady=10)
NH3.grid(row=12, pady=10)
CO.grid(row=14, pady=10)
SO2.grid(row=16, pady=10)
O3.grid(row=18, pady=10)
Benzene.grid(row=20, pady=10)
Toluene.grid(row=22, pady=10)
Xylene.grid(row=24, pady=10)
AQI.grid(row=26, pady=10)

entry_1.grid(row=2,column=1, pady=10)
entry_2.grid(row=4,column=1, pady=10)
entry_3.grid(row=6,column=1, pady=10)
entry_4.grid(row=8,column=1, pady=10)
entry_5.grid(row=10,column=1, pady=10)
entry_6.grid(row=12,column=1, pady=10)
entry_7.grid(row=14,column=1, pady=10)
entry_8.grid(row=16,column=1, pady=10)
entry_9.grid(row=18,column=1, pady=10)
entry_10.grid(row=20,column=1, pady=10)
entry_11.grid(row=22,column=1, pady=10)
entry_12.grid(row=24,column=1, pady=10)
entry_13.grid(row=26,column=1, pady=10)


myText = StringVar();
but = Button(win, text="Predict",width=20,font=("bold",13),bg='blue',fg='white', command= prediction_model)
but.grid(row=28,columnspan=2, pady=10)

result = Label(win, text="",width=50,font=("bold",13), textvariable=myText).grid(row=29)
win.mainloop()

