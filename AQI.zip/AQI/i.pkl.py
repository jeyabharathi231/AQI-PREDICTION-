import pandas as pd 
import pickle
a=pickle.dump('hi.pkl',rb)
df=pd.read_csv("city_day.csv")
df=df.drop(['Date','PM2.5'],axis=1)

df['AQI_Bucket']=df['AQI_Bucket'].fillna('Modearte')
mean_value=df['AQI'].mean()
df['AQI'].fillna(value=mean_value, inplace=True)

df['PM10'].fillna(value=mean_value, inplace=True)
mean_value=df['PM10'].mean()
df['NO'].fillna(value=mean_value, inplace=True)
mean_value=df['NO'].mean()
df['NO2'].fillna(value=mean_value, inplace=True)
mean_value=df['NO2'].mean()
df['NOx'].fillna(value=mean_value, inplace=True)
mean_value=df['NOx'].mean()
df['CO'].fillna(value=mean_value, inplace=True)
mean_value=df['CO'].mean()
df['SO2'].fillna(value=mean_value, inplace=True)
mean_value=df['SO2'].mean()
df['O3'].fillna(value=mean_value, inplace=True)
mean_value=df['O3'].mean()
df['Benzene'].fillna(value=mean_value, inplace=True)
mean_value=df['Benzene'].mean()
df['Toluene'].fillna(value=mean_value, inplace=True)
mean_value=df['Toluene'].mean()
df['Xylene'].fillna(value=mean_value, inplace=True)
mean_value=df['Xylene'].mean()
df['Xylene'].fillna(value=mean_value, inplace=True)
mean_value=df['Xylene'].mean()
# df['PM2.5'].fillna(value=mean_value, inplace=True)
# mean_value=df['PM2.5'].mean()
df['NH3'].fillna(value=mean_value, inplace=True)
mean_value=df['NH3'].mean() 




from sklearn.preprocessing import LabelEncoder
l=LabelEncoder()
df['City']=l.fit_transform(df['City'])
df['AQI_Bucket']=l.fit_transform(df['AQI_Bucket'])


x_train, x_test, y_train, y_test = train_test_split(x, y, train_size = .75)
from sklearn.ensemble import RandomForestClassifier
c = RandomForestClassifier()
c.fit(x_train,y_train)
pred =c.predict(x_test)
from  sklearn.metrics import accuracy_score
Acc=accuracy_score(pred,y_test)
print("accuracy for randomforest:",Acc)
print("confusion matrix:")
m=confusion_matrix(y_test,pred)
print(m) 