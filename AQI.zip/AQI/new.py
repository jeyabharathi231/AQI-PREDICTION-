import pandas as pd  
#import matplotlib.pyplot as plt
df=pd.read_csv("car_evaluations.csv")
print(df.head(7))
print(df.info())
print(df.describe())
#preprocessing 
print(df.isnull())
print (df.isna().sum())

