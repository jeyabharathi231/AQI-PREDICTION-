from flask import Flask,send_file, request
import numpy as np
import pickle


app = Flask(__name__)
model = pickle.load(open('models.sav','rb'))


@app.route('/',methods=['GET'])
def Home():
    return send_file('index.html')

@app.route("/predict", methods=['POST'])
def predict():
    if request.method == 'POST':
        City = float(request.form['City'])
        PM10 = float(request.form['PM10'])
        NO= float(request.form['NO'])
        NO2= float(request.form['NO2'])
        NOx= int(request.form['NOx'])
        NH3= int(request.form['NH3'])
        CO= float(request.form['CO'])
        SO2= float(request.form['SO2'])
        O3= float(request.form['O3'])
        Benzene= int(request.form['Benzene'])
        Toluene= int(request.form['Toluene'])
        Xylene= int(request.form['Xylene'])
        AQI= float(request.form['AQI'])
        

        values = np.array([[City,PM10,NO,NO2,NOx,NH3,CO,SO2,O3,Benzene,Toluene,Xylene, AQI]])
        prediction = model.predict(values)

        return send_file('result.html', prediction=prediction)


if __name__ == "__main__":
    app.run()
